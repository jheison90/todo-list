
//const URL = 'http://192.168.0.18:8000/api/'; 
const URL = 'http://ec2-18-118-222-41.us-east-2.compute.amazonaws.com/api/'; 

export  {URL};
