Tecnologias usadas: 

Laravel 8 (PHP) para Backend
ReactJs para Frontend
Bootstrap para el diseño responsive
Axios para llamados a la API
Base de datos MySql

La aplicacón esta alojada en AWS con el servicio ELB